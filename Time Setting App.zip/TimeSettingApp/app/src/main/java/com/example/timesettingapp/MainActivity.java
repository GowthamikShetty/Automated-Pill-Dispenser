package com.example.timesettingapp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice hc05Device;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;

    private TextView tvStatus, tvDoseList;
    private TimePicker timePickerDose;
    private Button btnConnect, btnAddDose, btnSaveDoses;

    private ArrayList<String> doseTimes = new ArrayList<>();
    private static final int MAX_DOSES = 3;
    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 1;

    private static final UUID HC05_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        tvDoseList = findViewById(R.id.tvDoseList);
        timePickerDose = findViewById(R.id.timePickerDose);
        timePickerDose.setIs24HourView(true);
        btnConnect = findViewById(R.id.btnConnect);
        btnAddDose = findViewById(R.id.btnAddDose);
        btnSaveDoses = findViewById(R.id.btnSaveDoses);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show();
            finish();
        }

        btnConnect.setOnClickListener(v -> checkPermissionsAndConnect());
        btnAddDose.setOnClickListener(v -> addDoseTime());
        btnSaveDoses.setOnClickListener(v -> sendDoses());
    }

    private void checkPermissionsAndConnect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        REQUEST_BLUETOOTH_PERMISSIONS);
                return;
            }
        }
        connectHC05();
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                connectHC05();
            } else {
                Toast.makeText(this,
                        "Bluetooth permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private boolean hasBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void connectHC05() {
        if (!bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "Enable Bluetooth first", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!hasBluetoothPermission()) return;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
        if (paired == null || paired.size() == 0) {
            Toast.makeText(this, "No paired devices found", Toast.LENGTH_SHORT).show();
            return;
        }

        hc05Device = null;
        for (BluetoothDevice d : paired) {
            if (d.getName() != null && d.getName().contains("HC-05")) {
                hc05Device = d;
                break;
            }
        }

        if (hc05Device == null) {
            Toast.makeText(this, "HC-05 not found", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            try {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                bluetoothAdapter.cancelDiscovery();
                bluetoothSocket = hc05Device.createRfcommSocketToServiceRecord(HC05_UUID);
                bluetoothSocket.connect();
                outputStream = bluetoothSocket.getOutputStream();

                sendRtcToArduino();

                runOnUiThread(() -> tvStatus.setText("Connected & RTC Synced"));
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> tvStatus.setText("Connection Failed"));
            }
        }).start();
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private void addDoseTime() {
        if (doseTimes.size() >= MAX_DOSES) {
            Toast.makeText(this, "Max 3 doses allowed", Toast.LENGTH_SHORT).show();
            return;
        }

        int h = timePickerDose.getHour();
        int m = timePickerDose.getMinute();

        doseTimes.add(String.format(Locale.US, "%02d:%02d", h, m));
        updateDoseList();
    }

    private void updateDoseList() {
        StringBuilder sb = new StringBuilder("Selected Times:\n");
        for (int i = 0; i < doseTimes.size(); i++) {
            sb.append("Dose ").append(i + 1).append(": ").append(doseTimes.get(i)).append("\n");
        }
        tvDoseList.setText(sb.toString());
    }

    // Always send 3 times (pad with 00:00)
    private void sendDoses() {
        if (outputStream == null) {
            Toast.makeText(this, "Not connected", Toast.LENGTH_SHORT).show();
            return;
        }

        ArrayList<String> padded = new ArrayList<>();
        for (int i = 0; i < MAX_DOSES; i++) {
            if (i < doseTimes.size()) padded.add(doseTimes.get(i));
            else padded.add("00:00");
        }

        String packet = padded.get(0) + "," + padded.get(1) + "," + padded.get(2) + "\n";

        new Thread(() -> {
            try {
                outputStream.write(packet.getBytes());
                Thread.sleep(80);

                runOnUiThread(() -> tvStatus.setText("Sent: " + packet.trim()));
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> tvStatus.setText("Sending Failed"));
            }
        }).start();
    }

    private void sendRtcToArduino() throws IOException {
        Calendar c = Calendar.getInstance();
        String cmd = String.format(Locale.US, "RTCTIME %02d:%02d:%02d\n",
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                c.get(Calendar.SECOND));

        outputStream.write(cmd.getBytes());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (outputStream != null) outputStream.close();
            if (bluetoothSocket != null) bluetoothSocket.close();
        } catch (Exception ignored) {}
    }
}